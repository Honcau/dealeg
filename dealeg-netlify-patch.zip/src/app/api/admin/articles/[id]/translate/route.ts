import { NextRequest, NextResponse } from 'next/server';
import { getAdminToken, COOKIE_NAME }                 from '@/lib/admin-auth';
import { translateArticle, translateArticleLocale }   from '@/lib/translation';

export const runtime = 'nodejs';
// maxDuration chỉ Vercel dùng; Netlify bỏ qua (free = 10s, Pro = 26s).
// Vì vậy admin UI gọi endpoint này MỖI LOCALE một lần → mỗi request ~3-6s, an toàn.

function checkAuth(req: NextRequest) {
  try { return req.cookies.get(COOKIE_NAME)?.value === getAdminToken(); }
  catch { return false; }
}

type Params = { params: Promise<{ id: string }> };

/**
 * POST /api/admin/articles/[id]/translate
 *   body { locale: "fr" }  → dịch đúng 1 ngôn ngữ (dùng trên Netlify, tránh timeout)
 *   body {} hoặc không có   → dịch tất cả (chỉ nên dùng khi chạy local)
 */
export async function POST(req: NextRequest, { params }: Params) {
  if (!checkAuth(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { id } = await params;

  let locale: string | undefined;
  try {
    const body = await req.json();
    locale = body?.locale;
  } catch { /* không có body → dịch tất cả */ }

  try {
    // ── Chế độ 1 ngôn ngữ (mặc định cho Netlify) ──
    if (locale) {
      const result = await translateArticleLocale(id, locale);
      return NextResponse.json({ ok: result.success, ...result });
    }

    // ── Chế độ tất cả (local / timeout dài) ──
    const results = await translateArticle(id);
    const failed  = results.filter(r => !r.success);
    return NextResponse.json({
      ok:      true,
      results,
      summary: `${results.length - failed.length}/${results.length} ngôn ngữ thành công`,
    });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
